import "../global.css";

const Options = () => {
  return (
    <div className="text-5xl p-10 font-extrabold">
      <div>This is your options page.</div>
    </div>
  );
};

export default Options;
